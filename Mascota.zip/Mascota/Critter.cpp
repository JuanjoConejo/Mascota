#include "Critter.h" // Importa la definici� de la classe Critter del fitxer d'encap�alament.

Critter::Critter(int gana, int avorriment) : m_Gana(gana), m_Avorriment(avorriment) {}
// Constructor de la classe Critter que inicialitza els nivells de gana i avorriment amb els valors proporcionats.

void Critter::Xerra() {
    cout << "Hola soc la teva criatura!" << endl; // Mostra un missatge per pantalla.
    PassaTemps(); // Activa el m�tode privat PassaTemps.
}

void Critter::Menja(int menjar) {
    cout << "Esta molt bo! Estic menjant." << endl; // Mostra un missatge mentre la criatura menja.
    m_Gana -= menjar; // Redueix el nivell de gana segons l'argument menjar.
    PassaTemps(); // Actualitza l'estat de la criatura despr�s de menjar.
}

void Critter::Juga(int diversio) {
    cout << "Anem a passar-ho be!" << endl; // Mostra un missatge mentre la criatura juga.
    m_Avorriment -= diversio; // Redueix el nivell d'avorriment segons l'argument diversio.
    PassaTemps(); // Actualitza l'estat de la criatura despr�s de jugar.
}

void Critter::MostraEstat() {
    cout << "Nivell gana: " << m_Gana << ", Nivell avorriment: " << m_Avorriment << endl;
    // Mostra els nivells actuals de gana i avorriment.
}

void Critter::FaEsport() {
    cout << "La criatura esta fent esport." << endl; // Mostra un missatge quan la criatura fa esport.
    PassaTemps(); // Actualitza l'estat de la criatura despr�s de fer esport.
}

void Critter::PassaTemps(int temps) {
    m_Gana += temps; // Incrementa el nivell de gana amb el pas del temps.
    m_Avorriment += temps; // Incrementa el nivell d'avorriment amb el pas del temps.
}

Creature::Creature(int health) : m_Health(health) {} // Constructor de la classe base Creature que inicialitza la salut.

void Creature::DisplayHealth() const {
    cout << "Salut: " << m_Health << endl; // Mostra la salut de la criatura.
}

Orc::Orc(int health) : Creature(health) {} // Constructor de la classe Orc que crida al constructor de la classe Creature.

void Orc::Greet() const {
    cout << "L'orc et grunyit i et saluda." << endl; // Implementaci� del m�tode Greet per a Orc.
}

OrcBoss::OrcBoss() : Orc(180) {} // Constructor de la classe OrcBoss que crida al constructor de Orc amb una salut espec�fica.

void OrcBoss::Greet() const {
    cout << "L'orc et grunyix un hola especial." << endl; // Implementaci� del m�tode Greet per a OrcBoss.
}

Ogre::Ogre(int health) : Creature(health) {} // Constructor de la classe Ogre que crida al constructor de Creature.

void Ogre::Greet() const {
    cout << "L'ogre et saluda." << endl; // Implementaci� del m�tode Greet per a Ogre.
}