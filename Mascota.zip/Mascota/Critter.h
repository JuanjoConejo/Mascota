#ifndef CRITTER_H
#define CRITTER_H

#include <iostream>
#include <vector>

using namespace std;

class Critter {
public:
    Critter(int gana = 0, int avorriment = 0); // Constructor de la classe Critter amb valors per defecte per gana i avorriment.
    void Xerra(); // M�tode per fer que la criatura xerri.
    void Menja(int menjar = 4); // M�tode per fer que la criatura mengi amb un valor de menjar per defecte.
    void Juga(int diversio = 4); // M�tode per fer que la criatura jugui amb un valor de diversi� per defecte.
    void MostraEstat(); // M�tode per mostrar l'estat actual de la criatura.
    void FaEsport(); // M�tode per fer que la criatura faci esport.
    friend ostream& operator<<(ostream& os, const Critter& critter); // Sobrecarrega de l'operador d'impressi� per a la classe Critter.
    Critter& operator=(const Critter& critter); // Sobrecarrega de l'operador d'assignaci� per a la classe Critter.

private:
    int m_Gana; // Nivell de gana de la criatura.
    int m_Avorriment; // Nivell d'avorriment de la criatura.
    int GetEstil() const; // Funci� privada per obtenir l'estil de la criatura.
    void PassaTemps(int temps = 1); // Funci� privada per fer passar el temps a la criatura amb un valor per defecte.
};

class Granja {
public:
    Granja(); // Constructor de la classe Granja.
    void AgregarCriatura(const Critter& criatura); // M�tode per afegir una criatura a la granja.
    void MostrarCriaturas() const; // M�tode per mostrar totes les criatures de la granja.
    void MostrarCriaturaEspecifica(int indice) const; // M�tode per mostrar una criatura espec�fica de la granja.

private:
    vector<Critter> critters; // Vector per emmagatzemar les criatures de la granja.
};

class Creature {
public:
    Creature(int health = 100); // Constructor de la classe Creature amb salut per defecte.
    virtual void Greet() const = 0; // M�tode virtual pur per fer que la criatura saludi.
    virtual void DisplayHealth() const; // M�tode per mostrar la salut de la criatura.

protected:
    int m_Health; // Salut de la criatura.
};

class Orc : public Creature {
public:
    Orc(int health = 120); // Constructor de la classe Orc amb salut per defecte.
    virtual void Greet() const override; // Implementaci� del m�tode Greet per a l'Orc.
};

class OrcBoss : public Orc {
public:
    OrcBoss(); // Constructor de la classe OrcBoss.
    virtual void Greet() const override; // Implementaci� del m�tode Greet per a l'OrcBoss.
};

class Ogre : public Creature {
public:
    Ogre(int health = 180); // Constructor de la classe Ogre amb salut per defecte.
    virtual void Greet() const override; // Implementaci� del m�tode Greet per a l'Ogre.
};

#endif // CRITTER_H
