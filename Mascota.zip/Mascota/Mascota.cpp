#include <iostream>
#include "Critter.h" // Inclou l'arxiu d'encapçalament de la classe Critter.

using namespace std;

int main() {
    Critter crit; // Crea una instància de la classe Critter.
    Ogre unOgre; // Crea una instància de la classe Ogre.
    int opcio;

    // Inicia un bucle que s'executarà fins que l'usuari introdueixi l'opció 0 per sortir.
    do {
        cout << "\nCuidador de Criatures\n\n";
        cout << "0 Sortir\n"; // Mostra l'opció per sortir del programa.
        cout << "1 Escoltar la teva criatura\n"; // Mostra l'opció per escoltar la criatura.
        cout << "2 Donar menjar a la criatura\n"; // Mostra l'opció per donar menjar a la criatura.
        cout << "3 Jugar amb la criatura\n"; // Mostra l'opció per jugar amb la criatura.
        cout << "4 Estat de la criatura\n"; // Mostra l'opció per veure l'estat de la criatura.
        cout << "5 Esport amb la criatura\n"; // Mostra l'opció per fer esport amb la criatura.
        cout << "6 Mostrar Ogre\n"; // Mostra l'opció per mostrar l'Ogre.
        cout << "\nOpcio: "; // Demana a l'usuari que introdueixi una opció.
        cin >> opcio; // Llegeix l'opció introduïda per l'usuari.

        // Utilitza una estructura switch per gestionar les diferents opcions.
        switch (opcio) {
        case 0:
            cout << "Deu.\n"; // Missatge d'adeu quan l'usuari decideix sortir.
            break;
        case 1:
            crit.Xerra(); // Crida al mètode Xerra() de la classe Critter.
            break;
        case 2:
            crit.Menja(); // Crida al mètode Menja() de la classe Critter.
            break;
        case 3:
            crit.Juga(); // Crida al mètode Juga() de la classe Critter.
            break;
        case 4:
            crit.MostraEstat(); // Crida al mètode MostraEstat() de la classe Critter.
            break;
        case 5:
            crit.FaEsport(); // Crida al mètode FaEsport() de la classe Critter.
            break;
        case 6:
            unOgre.Greet(); // Crida al mètode Greet() de la classe Ogre.
            unOgre.DisplayHealth(); // Crida al mètode DisplayHealth() de la classe Ogre.
            break;
        default:
            cout << "\nPerdona, però " << opcio << " no és vàlida.\n"; // Missatge d'error quan l'opció introduïda no és vàlida.
            break;
        }
    } while (opcio != 0); // Continua el bucle fins que l'usuari introdueixi l'opció 0.

    return 0;
}
